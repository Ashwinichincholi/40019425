var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CricketMatch = /** @class */ (function () {
    function CricketMatch(currentscore, currentover, target) {
        this.currentover = currentover;
        this.currentscore = currentscore;
        this.target = target;
    }
    CricketMatch.prototype.remainingScore = function () {
        return this.target - this.currentscore;
    };
    CricketMatch.prototype.remainingBalls = function (over) {
        return (over - this.currentover) * 6;
    };
    CricketMatch.prototype.runRate = function (over) {
        return (this.target - this.currentscore) / (over - this.currentover);
    };
    return CricketMatch;
}());
var ODIMatch = /** @class */ (function (_super) {
    __extends(ODIMatch, _super);
    function ODIMatch(currentscore, currentover, target) {
        var _this = _super.call(this, currentscore, currentover, target) || this;
        _this.overs = 50;
        // this.requiredrunrate = requiredrunrate;
        _this.display();
        return _this;
    }
    ODIMatch.prototype.display = function () {
        console.log('Need ' + this.remainingScore() + ' runs in ' + this.remainingBalls(this.overs) + ' balls');
        console.log('Required Runrate:' + this.runRate(this.overs));
    };
    return ODIMatch;
}(CricketMatch));
var TestMatch = /** @class */ (function (_super) {
    __extends(TestMatch, _super);
    function TestMatch(currentscore, currentover, target) {
        var _this = _super.call(this, currentscore, currentover, target) || this;
        _this.overs = 90;
        // this.requiredrunrate = requiredrunrate;
        _this.display();
        return _this;
    }
    TestMatch.prototype.display = function () {
        console.log('Need ' + this.remainingScore() + ' runs in ' + this.remainingBalls(this.overs) + ' balls');
        console.log('Required Runrate:' + this.runRate(this.overs));
    };
    return TestMatch;
}(CricketMatch));
var T20Match = /** @class */ (function (_super) {
    __extends(T20Match, _super);
    function T20Match(currentscore, currentover, target) {
        var _this = _super.call(this, currentscore, currentover, target) || this;
        _this.overs = 20;
        // this.requiredrunrate = requiredrunrate;
        _this.display();
        return _this;
    }
    T20Match.prototype.display = function () {
        console.log('Need ' + this.remainingScore() + ' runs in ' + this.remainingBalls(this.overs) + ' balls');
        console.log('Required Runrate:' + this.runRate(this.overs));
    };
    return T20Match;
}(CricketMatch));
var T10Match = /** @class */ (function (_super) {
    __extends(T10Match, _super);
    function T10Match(currentscore, currentover, target) {
        var _this = _super.call(this, currentscore, currentover, target) || this;
        _this.overs = 10;
        // this.requiredrunrate = requiredrunrate;
        _this.display();
        return _this;
    }
    T10Match.prototype.display = function () {
        console.log('Need ' + this.remainingScore() + ' runs in ' + this.remainingBalls(this.overs) + ' balls');
        console.log('Required Runrate:' + this.runRate(this.overs));
    };
    return T10Match;
}(CricketMatch));
var match = new ODIMatch(256, 30, 400);
//let testmatch=new TestMatch (256,30,400);
var t20 = new T20Match(120, 15, 170);
//let t10= new T10Match(125,20,180);
