var Customer = /** @class */ (function () {
    function Customer(name, address, mobile) {
        this.name = name;
        this.address = address;
        this.mobile = mobile;
    }
    Customer.prototype.display = function () {
        console.log('Name:', this.name);
        console.log('Address:', this.address);
        console.log('Mobile:', this.mobile);
    };
    return Customer;
}());
var customer = new Customer("Ravi", "pune", "873267");
customer.display();
